const fs = require("fs");
const axios = require("axios");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = ""; // Ganti dengan token bot

// ----- ( jangan ubah kalo gapaham) ------ \\
const ADMIN_FILE = "admin.json";
const RESELLER_FILE = "resellers.json";
const GITHUB_REPO = "";
const GITHUB_FILE_PATH = "";
const GITHUB_PAT = ""; 


const GITHUB_RAW_URL = ``
GITHUB_API_URL = ``;


async function fetchTokens() {
  try {
    const response = await axios.get(GITHUB_RAW_URL, { headers: { "Cache-Control": "no-cache" } });
    return response.data?.tokens || [];
  } catch (error) {
    return [];
  }
}

async function updateTokens(tokens) {
  try {
    if (!tokens || tokens.length === 0) {
      console.warn("No tokens to update.");
      return true; // Atau false, tergantung logika Anda
    }

    const { data: { sha, content } } = await axios.get(GITHUB_API_URL, {
      headers: { Authorization: `token ${GITHUB_PAT}` },
    });

    // Periksa apakah GET berhasil dan sha ada
    if (!sha) {
      console.error("Failed to get SHA from GitHub API.");
      return false;
    }

    const updatedContent = Buffer.from(JSON.stringify({ tokens }, null, 2)).toString("base64");

    await axios.put(
      GITHUB_API_URL,
      { message: "Update token list", content: updatedContent, sha: sha },
      { headers: { Authorization: `token ${GITHUB_PAT}` } }
    );

    return true;
  } catch (error) {
    console.error("Error updating tokens:", error);
    return false;
  }
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function loadAdmins() {
  if (!fs.existsSync(ADMIN_FILE)) return { owners: [], admins: [] };
  return JSON.parse(fs.readFileSync(ADMIN_FILE));
}

function loadResellers() {
  if (!fs.existsSync(RESELLER_FILE)) return { resellers: [] };
  return JSON.parse(fs.readFileSync(RESELLER_FILE));
}

function saveAdmins(adminData) {
  fs.writeFileSync(ADMIN_FILE, JSON.stringify(adminData, null, 2));
}

function saveResellers(resellerData) {
  fs.writeFileSync(RESELLER_FILE, JSON.stringify(resellerData, null, 2));
}


function isOwner(userId) {
  return loadAdmins().owners.includes(userId);
}

function isAdmin(userId) {
  const { admins, owners } = loadAdmins();
  return owners.includes(userId) || admins.includes(userId);
}

function isReseller(userId) {
  return loadResellers().resellers.includes(userId);
}

function hasAccess(userId) {
  return isOwner(userId) || isAdmin(userId) || isReseller(userId);
}

const MENU_VIDEO = "https://files.catbox.moe/6mn4ik.mp4";

// ---- ( Main Menu ---- \\

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!hasAccess(userId)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  const menuText = "```\n𝕆𝕋𝔸𝕏 𝔸𝔻𝔻 𝕋𝕆𝕂𝔼ℕ\n╭━━━━⭓\n" +
                   "┃➺ /listtoken (Lihat daftar token)\n" +
                   "┃➺ /addtoken (Tambah token baru)\n" +
                   "┃➺ /deltoken (Hapus token)\n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓\n\n" +
                   "╭━━━━⭓ʀᴇsᴇʟʟᴇʀ ᴍᴇɴᴜᯓ★\n" +
                   "┃➺ /listreseller (ʟɪʜᴀᴛ ᴅᴀғᴛᴀʀ ʀᴇsᴇʟʟᴇʀ)\n" +
                   "┃➺ /addreseller (ᴛᴀᴍʙᴀʜ ʀᴇsᴇʟʟᴇʀ)\n" +
                   "┃➺ /delreseller (ʜᴀᴘᴜs ʀᴇsᴇʟʟᴇʀ)\n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓\n\n" +
                   "╭━━━━⭓ᴏᴡɴᴇʀ ᴍᴇɴᴜᯓ★\n" +
                   "┃➺ /addvip (ᴛᴀᴍʙᴀʜ ᴀᴅᴍɪɴ ᴛᴀᴍʙᴀʜᴀɴ)\n" +
                   "┃➺ /addtoken (ᴛᴀᴍʙᴀʜ ᴛᴏᴋᴇɴ ʙᴀʀᴜ)\n" +
                   "┃➺ /delpt (ʜᴀᴘᴜs ᴀᴅᴍɪɴ ᴛᴀᴍʙᴀʜᴀɴ)\n" +
                   "╰━━━━━━━━━━━━━━━━━━⭓```";

  bot.sendVideo(chatId, MENU_VIDEO, { caption: menuText, parse_mode: "MarkdownV2" });
});


// ---- ( Bot OnText Zone ) -----

bot.onText(/\/addvip (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newAdminId = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menambah admin!");
  if (isNaN(newAdminId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (adminData.admins.includes(newAdminId)) return bot.sendMessage(chatId, "⚠️ Admin sudah ada!");

  adminData.admins.push(newAdminId);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Vip tambahan berhasil ditambahkan: ${newAdminId}`);
});

bot.onText(/\/delvip (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const adminToRemove = parseInt(match[1]);

  if (!isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner yang bisa menghapus admin!");
  if (isNaN(adminToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const adminData = loadAdmins();
  if (!adminData.admins.includes(adminToRemove)) return bot.sendMessage(chatId, "⚠️ Admin tidak ditemukan!");

  adminData.admins = adminData.admins.filter((id) => id !== adminToRemove);
  saveAdmins(adminData);
  bot.sendMessage(chatId, `✅ Vip tambahan berhasil dihapus: ${adminToRemove}`);
});


bot.onText(/\/addreseller (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const newResellerId = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menambah reseller!");
  if (isNaN(newResellerId)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (resellerData.resellers.includes(newResellerId)) return bot.sendMessage(chatId, "⚠️ Reseller sudah ada!");

  resellerData.resellers.push(newResellerId);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ Reseller berhasil ditambahkan: ${newResellerId}`);
});

bot.onText(/\/delreseller (\d+)/, (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const resellerToRemove = parseInt(match[1]);

  if (!isAdmin(userId) && !isOwner(userId)) return bot.sendMessage(chatId, "❌ Hanya owner dan admin yang bisa menghapus reseller!");
  if (isNaN(resellerToRemove)) return bot.sendMessage(chatId, "❌ ID harus berupa angka!");

  const resellerData = loadResellers();
  if (!resellerData.resellers.includes(resellerToRemove)) return bot.sendMessage(chatId, "⚠️ Reseller tidak ditemukan!");

  resellerData.resellers = resellerData.resellers.filter((id) => id !== resellerToRemove);
  saveResellers(resellerData);
  bot.sendMessage(chatId, `✅ Reseller berhasil dihapus: ${resellerToRemove}`);
});

bot.onText(/\/listreseller/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  if (!isAdmin(userId) && !isOwner(userId)) {
    return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
  }

  const resellers = loadResellers().resellers || [];
  bot.sendMessage(chatId, `👥 **Daftar Reseller:**\n\n${resellers.map((r, i) => `${i + 1}. ${r}`).join("\n") || "🚫 Tidak ada reseller!"}`, { parse_mode: "Markdown" });
});

bot.onText(/\/addtoken (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const newToken = match[1].trim();
    if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  let tokens = await fetchTokens();
  if (tokens.includes(newToken)) return bot.sendMessage(chatId, "⚠️ Token sudah ada dalam database");

  tokens.push(newToken);
  const success = await updateTokens(tokens);

  if (success) bot.sendMessage(chatId, `✅ Token berhasil ditambahkan!`);
  else bot.sendMessage(chatId, "❌ Gagal menambahkan token!");
});

bot.onText(/\/deltoken (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const tokenToRemove = match[1].trim();

    // Cek akses pengguna
    if (!hasAccess(msg.from.id)) {
        return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");
    }

    try {
        // Ambil daftar token yang ada
        let tokens = await fetchTokens();

        // Hapus token dari daftar (filter akan menangani jika token tidak ada)
        tokens = tokens.filter(token => token !== tokenToRemove);

        // Perbarui daftar token
        const success = await updateTokens(tokens);

        // Kirim pesan sukses atau gagal
        if (success) {
            bot.sendMessage(chatId, `✅ Token "${tokenToRemove}" berhasil dihapus!`);
        } else {
            bot.sendMessage(chatId, `❌ Gagal menghapus token "${tokenToRemove}"! Periksa log untuk detail error.`);
        }
    } catch (error) {
        console.error("Error deleting token:", error);
        bot.sendMessage(chatId, `❌ Terjadi kesalahan: ${error.message}`);
    }
});

bot.onText(/\/listtoken/, async (msg) => {
  const chatId = msg.chat.id;
  const tokens = await fetchTokens();
    if (!hasAccess(msg.from.id)) return bot.sendMessage(chatId, "❌ Anda tidak memiliki akses!");

  if (tokens.length === 0) return bot.sendMessage(chatId, "⚠️ Tidak ada token tersimpan.");

  let tokenList = tokens.map((t) => `${t.slice(0, 3)}***${t.slice(-3)}`).join("\n");
  bot.sendMessage(chatId, `📜 **Daftar Token:**\n\`\`\`${tokenList}\`\`\``, { parse_mode: "Markdown" });
});


fetchTokens();
console.log("🚀 Bot Token Manager berjalan...");